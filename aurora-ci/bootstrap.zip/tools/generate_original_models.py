from pathlib import Path
import numpy as np, trimesh, random, math, os
from PIL import Image, ImageDraw, ImageFilter
ROOT=Path(__file__).resolve().parents[1]
for d in ['assets/models','assets/textures','scripts','scenes','shaders','docs']:(ROOT/d).mkdir(parents=True,exist_ok=True)
random.seed(1904)
def rgb(hexstr):return np.array(tuple(int(hexstr[i:i+2],16) for i in (1,3,5)) + (255,),dtype=np.uint8)
def colorize(m,c):
 m.visual.vertex_colors=np.tile(rgb(c),(len(m.vertices),1));return m
def uvball(center,scale,color,sub=1):
 m=trimesh.creation.icosphere(subdivisions=sub,radius=1.0); m.apply_scale(scale);m.apply_translation(center);return colorize(m,color)
def cylinder(p,q,radius,color,sections=7,r2=None):
 p=np.array(p,float);q=np.array(q,float); delta=q-p;length=np.linalg.norm(delta)
 if not length:return None
 if r2 is None:
  m=trimesh.creation.cylinder(radius=radius,height=length,sections=sections)
 else:
  # cone axis along Z
  m=trimesh.creation.cone(radius=radius,height=length,sections=sections) if r2==0 else None
  if m is None:
   a=np.linspace(0,2*np.pi,sections,endpoint=False)
   vertices=np.array([[r*np.cos(t),r*np.sin(t),z] for z,r in ((-length/2,radius),(length/2,r2)) for t in a])
   faces=[]
   for i in range(sections):
    j=(i+1)%sections;faces.extend([[i,j,sections+j],[i,sections+j,sections+i]])
   faces.extend([[0,j+1,j] for j in range(1,sections-1)])
   faces.extend([[sections,sections+j,sections+j+1] for j in range(1,sections-1)])
   m=trimesh.Trimesh(vertices=vertices,faces=faces,process=False)
 matrix=trimesh.geometry.align_vectors([0,0,1],delta/length);m.apply_transform(matrix);m.apply_translation((p+q)/2)
 return colorize(m,color)
def box(center,scale,col):
 m=trimesh.creation.box(extents=scale);m.apply_translation(center);return colorize(m,col)
def export(name,meshes):
 meshes=[m for m in meshes if m is not None]
 m=trimesh.util.concatenate(meshes)
 out=ROOT/'assets/models'/name
 m.export(str(out));print(name,'meshes',len(meshes),'vertices',len(m.vertices),'size',out.stat().st_size)

def broadleaf(name,base,leaves,white=False):
 rng=random.Random(sum(map(ord,name)));ms=[]
 h=rng.uniform(8.4,10.7)
 basecol='#DDD5BD' if white else '#6E4236'
 ms.append(cylinder((0,.03,0),(rng.uniform(-.2,.2),h*.93,0),.23 if white else .32,basecol,9,r2=.09))
 for i in range(7 if white else 9):
  y=(.4+i)*h/10; side=rng.uniform(-1,1);angle=i*2.399; sx=math.cos(angle)*rng.uniform(1.35,3.2);sz=math.sin(angle)*rng.uniform(1.2,2.8)
  tip=(sx,y+rng.uniform(1.4,2.7),sz)
  ms.append(cylinder((0,y,0),tip,rng.uniform(.07,.12),'#735244' if white else '#55382F',6,r2=.018))
  for j in range(4):
   phi=2*math.pi*j/4+angle;pos=(tip[0]+math.cos(phi)*rng.uniform(.3,.75),tip[1]+rng.uniform(-.45,.65),tip[2]+math.sin(phi)*rng.uniform(.3,.75))
   col=rng.choice(leaves);ms.append(uvball(pos,(rng.uniform(.65,1.0),rng.uniform(.63,1.15),rng.uniform(.6,.9)),col,sub=1))
 for i in range(10):
  y=h*rng.uniform(.56,.98);radius=rng.uniform(0.3,2.0);a=rng.uniform(0,6.28)
  ms.append(uvball((radius*math.cos(a),y,radius*math.sin(a)),(.75,.8,.76),rng.choice(leaves)))
 if white:
  for i in range(12):
   y=rng.uniform(.7,h*.7);a=rng.uniform(0,6.28)
   ms.append(box((.25*math.cos(a),y,.25*math.sin(a)),(.05,.13,.08),'#514B45'))
 export(name,ms)

broadleaf('birch_gold.glb','#EBD58B',['#EAB83E','#F3D05F','#DF8C2C','#F1A848','#F6DC75'],True)
broadleaf('maple_amber.glb','#DC7B26',['#DC6E21','#F49F29','#E8AF3E','#CB4420','#EFCC5B'],False)
broadleaf('maple_ruby.glb','#B74323',['#B44431','#E26433','#B92D22','#D77F25','#E1AC38'],False)
broadleaf('birch_pale.glb','#F3D58F',['#EAD18A','#F4E6B2','#DDA95B','#D39F42'],True)

def spruce(name,snow=True):
 rng=random.Random(900 if snow else 500);ms=[]
 h=11 if snow else 10
 ms.append(cylinder((0,.05,0),(0,h,0),.32,'#514437',9,r2=.05))
 for layer in range(8):
  y=1.4+layer*1.0;span=2.5*(1-layer/10)
  for a_idx in range(6):
   a=2*np.pi*a_idx/6+layer*.3
   p=(span*math.cos(a),y-.4,span*math.sin(a));ms.append(cylinder((0,y+.85,0),p,.09,'#493F38',5,r2=.01))
   for frac in (0.48,.82):
    pc=np.array([p[0]*frac,y+0.65-frac*1.2,p[2]*frac]);
    # overlapping conical tufts, colour varied
    col=rng.choice(['#1B4846','#255D57','#31655B','#245049'])
    ms.append(uvball(tuple(pc),(.47 if frac<.7 else .65,.26,.65),col,sub=1))
    if snow:
     ms.append(uvball((pc[0],pc[1]+.18,pc[2]),(.51 if frac<.7 else .61,.12,.54),'#D9F2F4' if rng.random()<.6 else '#F3FEFD',sub=1))
 export(name,ms)
spruce('snow_pine.glb',True)
spruce('dark_pine.glb',False)
export('moss_rock.glb',[uvball((0,.6,0),(1.45,.74,1.1),'#696F65',1),uvball((-.43,.97,.15),(.67,.18,.63),'#536D4C',1),uvball((.77,.5,-.1),(.55,.37,.67),'#7B8071',1)])
export('ice_rock.glb',[uvball((0,.88,0),(1.2,1.05,1.05),'#516E80',1),uvball((.18,1.75,-.1),(.6,.18,.6),'#BDDBE3',1),uvball((-.65,.4,.2),(.6,.27,.75),'#789BA9',1)])

def fern():
 ms=[];rng=random.Random(42)
 for i in range(7):
  a=i*2*np.pi/7;tip=np.array((math.cos(a)*1.0,.3,math.sin(a)*1.0))
  ms.append(cylinder((0,.05,0),tuple(tip),.024,'#38582B',5,r2=.008))
  for t in range(2,7):
   f=t/7;pos=tip*f;side=np.array((-math.sin(a),0,math.cos(a)))
   for s in [-1,1]:
    # leaf as narrow ellipsoid
    cp=pos+side*s*.17;ms.append(uvball(tuple(cp),(.14,.03,.13),rng.choice(['#7E9243','#A1A951','#526B36']),0))
 export('fern.glb',ms)
fern()

def cabin():
 ms=[]
 # foundation/floor and walls
 ms.append(box((0,.25,0),(8,.5,7),'#66503A'))
 for z in [-3.3,3.3]:
  for h in range(1,12):
   y=.35+h*.26;ms.append(cylinder((-4,y,z),(4,y,z),.17,'#6C3F2B' if h%2 else '#7F5134',7))
 for x in [-3.9,3.9]:
  for h in range(1,12):
   y=.35+h*.26;ms.append(cylinder((x,y,-3.3),(x,y,3.3),.17,'#75482E' if h%2 else '#8C5935',7))
 # roof sloped tile-like planes made from planks angled
 ridge=5.8;edge=3.15
 for side in [-1,1]:
  for k in range(15):
   z=-3.9+(k+.5)*.55
   # from central ridge to edge: angled brown beams as thick cylinders
   ms.append(cylinder((0,ridge,z),(side*4.85,edge,z),.2,'#45372E',6))
   ms.append(cylinder((side*.23,ridge-.08,z),(side*4.73,edge+.14,z),.31,'#6B4635',6))
 # roof snow cap: upper oriented slab (via mesh quad extrude approximation)
 for s in [-1,1]:
  ms.append(cylinder((s*.7,5.63,-.02),(s*4.35,3.65,-.02),.42,'#D7E8ED',6))
 # door centered front at z=3.52
 ms.append(box((0,1.62,3.53),(1.85,2.85,.12),'#51331F'))
 for x in [-.68,-.24,.22,.67]:ms.append(box((x,1.55,3.66),(.055,2.58,.03),'#967347'))
 # windows side luminous cream
 for x in [-3.98,3.98]:
  ms.append(box((x,2.23,0),(.08,1.22,1.45),'#E8B257'))
  ms.append(box((x+(.12 if x<0 else -.12),2.23,0),(.12,.1,1.6),'#433324'))
  ms.append(box((x+(.12 if x<0 else -.12),2.23,0),(.12,1.28,.08),'#433324'))
 ms.append(cylinder((2.5,4.7,-.8),(2.5,7,-.8),.6,'#746C60',9))
 export('snow_cabin.glb',ms)
cabin()

def mushroom():
 ms=[cylinder((0,.05,0),(0,.54,0),.13,'#E9E0C6',8),uvball((0,.55,0),(.49,.23,.49),'#BF3A26',1)]
 export('toadstool.glb',ms)
mushroom()

# Terrain tile textures procedural, no internet asset dependencies
rng=np.random.default_rng(1837)
W=512
for kind in ['autumn_ground','snow_ground','cabin_wood','dirt_path']:
 a=np.zeros((W,W,3),dtype=np.uint8)
 if kind=='autumn_ground':base=np.array([85,75,40]); noise=23
 elif kind=='snow_ground':base=np.array([177,207,215]);noise=13
 elif kind=='cabin_wood':base=np.array([91,53,37]);noise=17
 else:base=np.array([125,84,49]);noise=24
 n=rng.normal(0,noise,(W,W,1));a[:]=np.clip(base+n,0,255)
 im=Image.fromarray(a,'RGB');dr=ImageDraw.Draw(im,'RGBA')
 if kind=='autumn_ground':
  for j in range(4900):
   x,y=int(rng.integers(W)),int(rng.integers(W));l=int(rng.integers(3,13));c=random.choice([(244,181,65,195),(225,103,35,180),(190,62,33,170),(119,126,58,160),(235,209,89,175)])
   dr.ellipse((x,y,x+l,y+l//2+1),fill=c)
 elif kind=='snow_ground':
  for j in range(2500):
   x,y=int(rng.integers(W)),int(rng.integers(W));k=int(rng.integers(1,5));dr.ellipse((x,y,x+k,y+k),fill=(240,253,255,int(rng.integers(40,140))))
 elif kind=='cabin_wood':
  for y in range(0,W,33):
   dr.line((0,y,W,y),fill=(35,29,25,180),width=3)
   for j in range(3):
    x=int(rng.integers(W));dr.line((x,y,x,y+32),fill=(46,31,24,90),width=2)
 else:
  for j in range(1700):
   x,y=int(rng.integers(W)),int(rng.integers(W));r=int(rng.integers(1,8));dr.ellipse((x,y,x+r,y+r),fill=(60,51,43,int(rng.integers(60,130))))
 im.save(ROOT/'assets/textures'/f'{kind}.png')
print('Asset total MB',sum(p.stat().st_size for p in (ROOT/'assets').rglob('*') if p.is_file())/1e6)

# Fallback icons for cloud CI: solid gradient with mountain, no rights issues.
for N in (192,432):
    canvas=Image.new('RGB',(N,N)); d=ImageDraw.Draw(canvas)
    for y in range(N):
        d.line((0,y,N,y),fill=(int(12+21*y/N),int(37+23*y/N),int(62+12*y/N)))
    d.polygon([(0,int(N*.83)),(int(N*.2),int(N*.43)),(int(N*.38),int(N*.65)),(int(N*.57),int(N*.34)),(N,int(N*.83)),(N,N),(0,N)],fill=(23,47,48))
    d.polygon([(int(N*.45),int(N*.52)),(int(N*.57),int(N*.34)),(int(N*.7),int(N*.52))],fill=(230,245,239))
    canvas.save(ROOT/'assets'/f'icon_{N}.png')
