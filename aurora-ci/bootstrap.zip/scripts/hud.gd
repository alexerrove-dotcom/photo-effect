extends CanvasLayer

# Touch UI is generated in code so it can adapt to different Android screen sizes.
var game: Variant
var hero: Variant
var overlay: Control
var joystick: Variant
var title_label: Label
var status_label: Label
var memories_label: Label
var hint_label: Label
var action_button: Button
var jump_button: Button
var run_button: Button
var worlds_button: Button
var menu_button: Button
var chooser: Panel
var start_panel: Panel
var shade: ColorRect
var start_button: Button
var camera_touch_id := -1
var screen_size := Vector2.ZERO
var menu_open := true

func setup(game_: Node3D, player_: CharacterBody3D) -> void:
    game = game_
    hero = player_
    _construct()
    _arrange()
    _update_place()
    show_start_menu(true)

func get_move() -> Vector2:
    if menu_open or joystick == null:
        return Vector2.ZERO
    return joystick.direction

func _font_label(text_: String, size_: int, color_: Color) -> Label:
    var l := Label.new()
    l.text = text_
    l.add_theme_color_override("font_color", color_)
    l.add_theme_font_size_override("font_size", size_)
    return l

func _style_button(text_: String, bg_: Color, font_size := 22) -> Button:
    var b := Button.new()
    b.text = text_
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_color_override("font_color", Color("F6F5ED"))
    b.add_theme_color_override("font_hover_color", Color("FFFFFF"))
    var normal := StyleBoxFlat.new()
    normal.bg_color = bg_
    normal.border_color = Color("B4C8D0")
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(17)
    b.add_theme_stylebox_override("normal", normal)
    var hovered := normal.duplicate()
    hovered.bg_color = bg_.lightened(0.18)
    b.add_theme_stylebox_override("hover", hovered)
    b.add_theme_stylebox_override("pressed", hovered)
    return b

func _construct() -> void:
    overlay = Control.new()
    overlay.name = "AdaptiveTouchUI"
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(overlay)
    joystick = load("res://scripts/joystick.gd").new()
    joystick.name = "MovementJoystick"
    joystick.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.add_child(joystick)
    title_label = _font_label("ЗОЛОТОЙ ЛЕС", 26, Color("FFF3D6"))
    overlay.add_child(title_label)
    status_label = _font_label("AURORA  /  BETWEEN SEASONS", 13, Color("D7E9ED"))
    overlay.add_child(status_label)
    memories_label = _font_label("✦ 0/3", 19, Color("FFE1A4"))
    overlay.add_child(memories_label)
    hint_label = _font_label("WASD / стик — движение    •    Мышь / свайп — камера", 16, Color("F1E8CF"))
    overlay.add_child(hint_label)
    worlds_button = _style_button("МИРЫ", Color(0.10, 0.22, 0.32, 0.83), 17)
    worlds_button.pressed.connect(_toggle_worlds)
    overlay.add_child(worlds_button)
    menu_button = _style_button("☰", Color(0.10, 0.22, 0.32, 0.83), 23)
    menu_button.pressed.connect(func(): show_start_menu(not menu_open))
    overlay.add_child(menu_button)
    run_button = _style_button("БЕГ", Color(0.10, 0.25, 0.36, 0.65), 18)
    run_button.button_down.connect(func(): hero.run_pressed = true)
    run_button.button_up.connect(func(): hero.run_pressed = false)
    overlay.add_child(run_button)
    jump_button = _style_button("ПРЫЖОК", Color(0.21, 0.40, 0.49, 0.78), 17)
    jump_button.pressed.connect(func(): hero.request_jump())
    overlay.add_child(jump_button)
    action_button = _style_button("ВОЙТИ", Color(0.47, 0.34, 0.15, 0.92), 17)
    action_button.pressed.connect(func(): game.use_portal())
    overlay.add_child(action_button)
    chooser = Panel.new()
    var chooser_style := StyleBoxFlat.new()
    chooser_style.bg_color = Color(0.055, 0.10, 0.15, .94)
    chooser_style.set_corner_radius_all(20)
    chooser.add_theme_stylebox_override("panel", chooser_style)
    chooser.visible = false
    overlay.add_child(chooser)
    var options := ["ОСЕННИЙ ЛЕС", "СНЕЖНЫЕ ГОРЫ", "ТЁПЛАЯ ХИЖИНА"]
    var targets := ["autumn", "winter", "cabin"]
    for i in range(3):
        var b := _style_button(options[i], Color("26465B"), 17)
        b.position = Vector2(15, 13 + i * 58)
        b.size = Vector2(207, 46)
        var dest: String = targets[i]
        b.pressed.connect(func():
            chooser.visible = false
            game.travel_to(dest)
        )
        chooser.add_child(b)
    shade = ColorRect.new()
    shade.color = Color(0.035, 0.052, 0.083, 0.86)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.mouse_filter = Control.MOUSE_FILTER_STOP
    overlay.add_child(shade)
    start_panel = Panel.new()
    var menu_style := StyleBoxFlat.new()
    menu_style.bg_color = Color(0.08, 0.12, 0.16, 0.95)
    menu_style.border_color = Color("B9A078")
    menu_style.set_border_width_all(2)
    menu_style.set_corner_radius_all(24)
    start_panel.add_theme_stylebox_override("panel", menu_style)
    overlay.add_child(start_panel)
    var brand := _font_label("AURORA", 49, Color("F4D8A1"))
    brand.position = Vector2(25, 15)
    brand.size = Vector2(460, 58)
    brand.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    start_panel.add_child(brand)
    var tagline := _font_label("BETWEEN SEASONS", 24, Color("CBDDE6"))
    tagline.position = Vector2(25, 82)
    tagline.size = Vector2(460, 37)
    tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    start_panel.add_child(tagline)
    var text_ := _font_label("Три атмосферных мира: осенний лес,\nсеверное сияние и уютная хижина.\n\nНайди 9 светящихся воспоминаний и порталы.\nНа телефоне: стик, ПРЫЖОК и БЕГ.", 17, Color("F2EBE0"))
    text_.position = Vector2(24, 136)
    text_.size = Vector2(462, 126)
    text_.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    start_panel.add_child(text_)
    start_button = _style_button("НАЧАТЬ ПУТЕШЕСТВИЕ", Color("A56833"), 20)
    start_button.position = Vector2(73, 278)
    start_button.size = Vector2(364, 58)
    start_button.pressed.connect(func(): show_start_menu(false))
    start_panel.add_child(start_button)

func _arrange() -> void:
    screen_size = get_viewport().get_visible_rect().size
    var w := screen_size.x
    var h := screen_size.y
    title_label.position = Vector2(28, 22)
    status_label.position = Vector2(29, 62)
    memories_label.position = Vector2(29, 88)
    hint_label.position = Vector2(maxf(24, w * 0.28), 23)
    worlds_button.position = Vector2(w - 223, 20)
    worlds_button.size = Vector2(125, 48)
    menu_button.position = Vector2(w - 86, 20)
    menu_button.size = Vector2(62, 48)
    jump_button.position = Vector2(w - 144, h - 154)
    jump_button.size = Vector2(122, 72)
    run_button.position = Vector2(w - 256, h - 108)
    run_button.size = Vector2(98, 64)
    action_button.position = Vector2(w - 235, h - 196)
    action_button.size = Vector2(213, 52)
    chooser.position = Vector2(w - 258, 80)
    chooser.size = Vector2(237, 198)
    start_panel.size = Vector2(510, 363)
    start_panel.position = Vector2((w - 510) * .5, (h - 363) * .5)
    joystick.queue_redraw()

func _process(_delta: float) -> void:
    var current_size := get_viewport().get_visible_rect().size
    if current_size != screen_size:
        _arrange()
    if not is_instance_valid(hero) or not is_instance_valid(game):
        return
    var dist: float = hero.global_position.distance_to(game.world.action_position)
    action_button.visible = not menu_open and dist < 5.5
    if action_button.visible:
        action_button.text = "ВОЙТИ  •  E" if game.world.biome != "cabin" else "ВЫЙТИ  •  E"
    hint_label.visible = not menu_open

func _update_place() -> void:
    if not is_instance_valid(game):
        return
    match game.world.biome:
        "winter":
            title_label.text = "СЕВЕРНОЕ СИЯНИЕ"
            status_label.text = "СНЕЖНЫЕ ГОРЫ / НОЧЬ"
        "cabin":
            title_label.text = "ДОМ У ОГНЯ"
            status_label.text = "УЮТНАЯ ХИЖИНА / ИНТЕРЬЕР"
        _:
            title_label.text = "ЗОЛОТОЙ ЛЕС"
            status_label.text = "ОСЕНЬ / ТЁПЛЫЙ СВЕТ"

func show_start_menu(show_: bool) -> void:
    menu_open = show_
    shade.visible = show_
    start_panel.visible = show_
    hero.movement_enabled = not show_
    hero.run_pressed = false
    chooser.visible = false
    jump_button.visible = not show_
    run_button.visible = not show_
    worlds_button.visible = not show_
    hint_label.visible = not show_
    menu_button.visible = not show_
    memories_label.visible = not show_
    if joystick != null:
        joystick.direction = Vector2.ZERO
        joystick.knob_offset = Vector2.ZERO
        joystick.queue_redraw()

func _toggle_worlds() -> void:
    chooser.visible = not chooser.visible

func notify_scene_changed() -> void:
    _update_place()
    chooser.visible = false

func _input(event: InputEvent) -> void:
    if menu_open or not is_instance_valid(hero):
        return
    var size_ := get_viewport().get_visible_rect().size
    if event is InputEventScreenTouch:
        if event.pressed and camera_touch_id < 0 and event.position.x > size_.x * .46 and event.position.y > size_.y * .18 and event.position.y < size_.y * .73:
            camera_touch_id = event.index
        elif not event.pressed and camera_touch_id == event.index:
            camera_touch_id = -1
    elif event is InputEventScreenDrag and event.index == camera_touch_id:
        hero.rotate_camera(event.relative)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        hero.rotate_camera(event.relative)

func set_memories(here: int, all_total: int) -> void:
    if is_instance_valid(memories_label):
        memories_label.text = "✦ %d / 3   |   ВСЕГО %d / 9" % [here, all_total]
