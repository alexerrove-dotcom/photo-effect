from pathlib import Path
import random, math, shutil
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFilter
SRC=Path('project_pre')
ROOT=Path('project')
if ROOT.exists():shutil.rmtree(ROOT)
shutil.copytree(SRC, ROOT, ignore=shutil.ignore_patterns('.godot','*.import'))
M=ROOT/'assets/models'; T=ROOT/'assets/textures'
# NOTE: Original procedural assets, generated with code; no restrictions on reuse.
def rgba(h): return np.array([int(h[i:i+2],16) for i in (1,3,5)]+[255],dtype=np.uint8)
def dye(mesh, color):
 mesh.visual.vertex_colors=np.tile(rgba(color),(len(mesh.vertices),1));return mesh
def ball(p,s,col,sub=1):
 b=trimesh.creation.icosphere(subdivisions=sub,radius=1);b.apply_scale(s);b.apply_translation(p);return dye(b,col)
def taper(a,b,r0,r1,col,sides=8):
 a=np.asarray(a,float); b=np.asarray(b,float);axis=b-a;L=np.linalg.norm(axis);sides=int(sides)
 ang=np.arange(sides)*2*np.pi/sides; verts=np.array([[r*np.cos(u),r*np.sin(u),z] for z,r in [(-L/2,r0),(L/2,r1)] for u in ang]); faces=[]
 for k in range(sides):j=(k+1)%sides;faces.extend([[k,j,sides+j],[k,sides+j,sides+k]])
 faces.extend([[0,i+1,i] for i in range(1,sides-1)]);faces.extend([[sides,sides+i,sides+i+1] for i in range(1,sides-1)])
 obj=trimesh.Trimesh(vertices=verts,faces=np.asarray(faces),process=False);obj.apply_transform(trimesh.geometry.align_vectors([0,0,1],axis/L));obj.apply_translation((a+b)*0.5);return dye(obj,col)
def slab(pos,size,col):
 mesh=trimesh.creation.box(extents=size);mesh.apply_translation(pos);return dye(mesh,col)
def leaf(center, size, angle, col):
 # Actual thin double-sided 3D leaf, not spherical primitive. Vein modelled as strong central fold.
 cx,cy,cz=center;rx,ry=size;normal=np.array([math.cos(angle),0,math.sin(angle)]);side=np.array([-math.sin(angle),0,math.cos(angle)])
 base=np.array([cx,cy,cz]);v=np.array([base+np.array([0,-ry*.54,0]),base+side*rx*.7+np.array([0,-ry*.1,0]),base+np.array([0,ry*.7,0])+normal*.1,base-side*rx*.7+np.array([0,-ry*.1,0]),base+normal*.22]);
 obj=trimesh.Trimesh(vertices=v,faces=[[0,1,4],[1,2,4],[2,3,4],[3,0,4],[4,1,0],[4,2,1],[4,3,2],[4,0,3]],process=False)
 return dye(obj,col)
def export(name,meshes):
 meshes=[m for m in meshes if m is not None];scene=trimesh.Scene();
 # combine into 1 vertex-color material mesh for much faster draw calls
 mesh=trimesh.util.concatenate(meshes);mesh.export(M/name)
 print(name,len(mesh.vertices),int((M/name).stat().st_size/1024),'KiB')

# BIRCH/MAPLE: actual bifurcated tree silhouettes with thousands of individual leaf cards.
def deciduous(name,kind,seed):
 r=random.Random(seed); birch='birch' in kind;gold='gold' in kind;red='red' in kind
 trunk='#DED6C8' if birch else '#61503E'
 bark_alt='#A29F94' if birch else '#8A6044'
 colors=(['#F5D453','#F2B83C','#DB952F','#F8D975','#E8A72D','#CB8838'] if gold else
  ['#EC8B2C','#FFB646','#F4A449','#D75E2D','#E5B34D','#FFC369'] if not red else
  ['#BD4323','#E25B27','#F0832F','#D95323','#EEAA33','#B23728'])
 H=12.8 if birch else 10.6;ms=[]
 # crooked main body w/multiple tapered segments + rings, birch bark scars
 chain=[(0,0,0),(r.uniform(-.15,.1),H*.34,0),(r.uniform(-.4,.3),H*.72,r.uniform(-.2,.25)),(r.uniform(-.5,.5),H*.94,.1)]
 for i in range(3):
  ms.append(taper(chain[i],chain[i+1],.31-i*.072,.27-i*.075,bark_alt if i==1 else trunk,10))
 if birch:
  for i in range(27):
   y=H*(.05+.027*i);x=chain[0][0]+math.sin(i*.8)*.2
   ms.append(slab((x,y,.23-i*.004),(.33 if i%5==0 else .14,.035,.028),'#3C3E3B'))
 # Higher thinner side branches, angled unevenly: canopy airy, no sphere blobs
 for i in range(13 if birch else 17):
  phi=i*2.4+r.uniform(-.3,.3);along=r.uniform(.39,.88);start=np.array([math.sin(along*2)*.2,along*H,math.cos(along*1.4)*.12]);extent=r.uniform(1.5,4.1) if not birch else r.uniform(1.3,3.2)
  tip=start+np.array([math.cos(phi)*extent,r.uniform(1.1,2.4),math.sin(phi)*extent])
  ms.append(taper(start,tip,r.uniform(.10,.15),.018,bark_alt if i%2 else trunk,7))
  for j in range(3):
   theta=phi+(.68 if j%2==0 else -.7)*r.uniform(.8,1.5);shoot=tip+np.array([math.cos(theta)*r.uniform(.6,1.5),r.uniform(-.4,.9),math.sin(theta)*r.uniform(.5,1.5)])
   ms.append(taper(tip,shoot,.032,.006,bark_alt,5))
   # clustered independently oriented broad leaf cards; lots of open space
   for k in range(19 if birch else 24):
    v=shoot+np.array([r.gauss(0,.48),r.gauss(0,.54),r.gauss(0,.48)]);
    ms.append(leaf(v,(r.uniform(.12,.28),r.uniform(.17,.36)),r.random()*math.tau,r.choice(colors)))
 # canopy strays
 for k in range(135):
  a=r.random()*math.tau; rad=r.uniform(.65,3.3);h=H*r.uniform(.66,1.02)
  ms.append(leaf((math.cos(a)*rad,h,math.sin(a)*rad),(.17,.26),r.random()*math.tau,r.choice(colors)))
 export(name,ms)
for name,kind,seed in [('birch_gold_v04.glb','birch_gold',10),('birch_pale_v04.glb','birch_gold',11),('maple_amber_v04.glb','maple',22),('maple_ruby_v04.glb','red',44)]:deciduous(name,kind,seed)

# Pine: layered needle fans with separate snow surfaces, not stacked cones.
def pine(name,snow,seed):
 r=random.Random(seed);ms=[];H=12.0 if snow else 14.3
 ms.append(taper((0,0,0),(0,H,0),.36,.035,'#4D4038',9))
 dark=['#123B3B','#19514B','#285A49','#153F41','#316A5E']
 for level in range(14):
  yy=.9+level*(H-1.6)/14;spread=(2.7 if snow else 2.8)*(1-level/15)**.88
  for k in range(7):
   a=2*math.pi*k/7+level*.41; end=(math.cos(a)*spread,yy-0.9,math.sin(a)*spread)
   ms.append(taper((0,yy+.5,0),end,.085,.01,'#3A3833',6))
   for j in range(6):
    f=.27+j*.12;anchor=np.array(end)*f+np.array([0,.18,0]);side=np.array([-math.sin(a),0,math.cos(a)])
    for sign in [-1,1]:
     pt=anchor+side*sign*(.18+.29*(1-level/17))
     ms.append(leaf(pt,(.17,.35 if j%2 else .26),a,r.choice(dark)))
   if snow:
    # snow mantel on outer branch, small contiguous clumps, visible above green needles
    if k%2==0 or level%3:
     p=np.array(end)*.72+np.array([0,.18,0]);ms.append(ball(p,(.45,.11,.31),'#D6F0FA' if k%3 else '#EBF7F8',0))
 export(name,ms)
pine('pine_snow_v04.glb',True,31);pine('pine_dark_v04.glb',False,34)

# Ground flora: tapered stems with leaf facets and sepals rather than primitive ellipsoids
def fern(name):
 r=random.Random(19);ms=[]
 for s in range(8):
  a=2*math.pi*s/8;tip=np.array([math.cos(a)*1.3,.2,math.sin(a)*1.3]);ms.append(taper([0,.1,0],tip,.036,.006,'#355536',5))
  tangent=np.array([-math.sin(a),0,math.cos(a)])
  for k in range(3,11):
   t=k/12;mid=tip*t+np.array([0,math.sin(t*math.pi)*.34,0])
   for side in [-1,1]:
    pos=mid+tangent*side*(.12+.15*(1-t));ms.append(leaf(pos,(.17,.21),a+(math.pi/2 if side>0 else -math.pi/2),r.choice(['#6C843E','#A0AE4C','#90A949','#4D713E'])))
 export(name,ms)
fern('fern_broad_v04.glb')

def rock(name,snow):
 r=random.Random(99);ms=[]
 for k in range(5):
  col=r.choice(['#455E65','#71818A','#3A4B54','#677880']) if snow else r.choice(['#5A5A4B','#5E6557','#77735E','#444E43','#746D58'])
  ms.append(ball((r.uniform(-.7,.7),r.uniform(.23,.75),r.uniform(-.65,.65)),(r.uniform(.45,.95),r.uniform(.45,.94),r.uniform(.53,.9)),col,sub=0))
  if snow and k%2==0:ms.append(ball((r.uniform(-.4,.4),1.25,r.uniform(-.3,.3)),(.55,.17,.53),'#E4F7FB',sub=0))
 export(name,ms)
rock('boulder_snow_v04.glb',True);rock('boulder_moss_v04.glb',False)

# Character custom game-ready parts; animation applied by existing pivots.
def loft(name,rings,col,segments=12):
 verts=[];faces=[]
 for y,rx,rz,ox,oz in rings:
  for i in range(segments):
   theta=i*math.tau/segments
   verts.append([ox+math.cos(theta)*rx,y,oz+math.sin(theta)*rz]);
 for s in range(len(rings)-1):
  for j in range(segments):
   j2=(j+1)%segments;u=s*segments;v=(s+1)*segments
   faces.extend([[u+j,u+j2,v+j],[u+j2,v+j2,v+j]])
 faces.extend([[0,j+1,j] for j in range(1,segments-1)])
 tail=(len(rings)-1)*segments
 faces.extend([[tail,tail+j,tail+j+1] for j in range(1,segments-1)])
 return dye(trimesh.Trimesh(vertices=verts,faces=faces,process=False),col)

def hero_torso():
 ms=[]
 ms.append(loft('',[(.95,.36,.29,0,0),(1.25,.42,.29,0,0),(1.75,.48,.29,0,0),(1.86,.35,.26,0,0)],'#234D87',14))
 ms.append(loft('',[(.94,.41,.32,0,0),(1.05,.42,.33,0,0),(1.14,.36,.29,0,0)],'#4A331F',12))
 # raised coat seams on sides, epaulettes, collar and gold belt tab
 ms.append(taper((-.36,1.56,-.22),(-.20,.92,-.28),.025,.014,'#AD8040',5));ms.append(taper((.36,1.56,-.22),(.2,.92,-.28),.025,.014,'#AD8040',5))
 ms.append(loft('',[(1.72,.25,.23,0,0),(1.92,.27,.25,0,-.03),(2.0,.18,.2,0,-.05)],'#1C3262',12))
 ms.append(loft('',[(1.91,.21,.21,0,-.03),(2.17,.27,.27,0,-.01),(2.35,.26,.24,0,0)],'#F2C69D',16))
 # hair and blue large hood around the head
 ms.append(loft('',[(2.17,.30,.31,0,.04),(2.33,.3,.30,0,.04),(2.42,.19,.23,0,.1)],'#40332A',16))
 ms.append(loft('',[(2.12,.36,.34,0,.10),(2.31,.33,.35,0,.12),(2.40,.26,.29,0,.14)],'#153766',16))
 # face visible from front -z (distant camera usually sees back)
 for x in [-.115,.115]:ms.append(ball((x,2.225,-.271),(.041,.045,.028),'#26303E',1))
 ms.append(ball((0,2.115,-.288),(.07,.038,.035),'#B77767',1))
 # satchel/ration bag, strap, straps on shoulders
 ms.append(loft('',[(1.05,.3,.18,0,.32),(1.7,.34,.18,0,.32)],'#6F4A2D',10))
 ms.append(taper((-.35,1.81,-.24),(.25,1.07,.49),.045,.045,'#AF8A53',6))
 ms.append(slab((0,1.15,-.33),(.18,.16,.045),'#E5BD75'))
 for x in [-.49,.49]:ms.append(slab((x,1.72,.02),(.2,.1,.36),'#355C8D'))
 export('hero_torso_v04.glb',ms)
hero_torso()

def hero_arm(name,side):
 ms=[]
 ms.append(loft('',[(-.02,.18,.2,0,0),(-.27,.155,.17,0,-.01),(-.56,.13,.15,0,-.06),(-.67,.16,.14,0,-.075)],'#1C3F78',12))
 ms.append(loft('',[(-.62,.16,.16,0,-.075),(-.76,.13,.14,0,-.08)],'#B6A58B',12))
 ms.append(taper((.09,-.02,-.09),(.085,-.55,-.16),.032,.022,'#C0A26A',6))
 export(name,ms)
hero_arm('hero_arm_v04.glb',1)
def hero_leg():
 ms=[];ms.append(loft('',[(0,.20,.21,0,0),(-.37,.175,.18,0,0),(-.68,.135,.14,0,-.02)],'#3B3B49',12))
 ms.append(loft('',[(-.55,.17,.16,0,-.07),(-.73,.19,.22,0,-.08),(-.83,.23,.29,0,-.16)],'#42332B',12))
 ms.append(slab((0,-.83,-.16),(.49,.075,.61),'#2D2525'))
 export('hero_leg_v04.glb',ms)
hero_leg()

# Texture additions: leaf litter with multiple size layers and detailed ground variation
r=np.random.default_rng(882)
W=1024
for name,base in [('autumn_ground_v04.png',[85,69,37]),('dirt_path_v04.png',[145,100,59]),('snow_ground_v04.png',[160,201,223]),('cabin_wood_v04.png',[97,61,43])]:
 pix=np.clip(np.asarray(base)[None,None,:]+r.normal(0,14,(W,W,1)),0,255).astype('uint8');im=Image.fromarray(pix,'RGB');d=ImageDraw.Draw(im,'RGBA')
 if 'autumn' in name:
  for n in range(18000):
   x=int(r.integers(W));y=int(r.integers(W));a=float(r.uniform(0,6.28));ll=int(r.integers(3,22));col=random.choice([(239,177,38,215),(202,96,32,195),(240,208,86,192),(150,75,35,170),(82,108,45,155)])
   d.polygon([(x,y),(x+math.cos(a)*ll,y+math.sin(a)*ll),(x+math.cos(a+1.1)*ll*.32,y+math.sin(a+1.1)*ll*.32)],fill=col)
 elif 'snow' in name:
  for n in range(26000):
   x=int(r.integers(W));y=int(r.integers(W));R=int(r.integers(1,7));d.ellipse((x,y,x+R,y+R),fill=(235,248,255,int(r.integers(65,180))))
 elif 'wood' in name:
  for y in range(0,W,46):
   d.line((0,y,W,y), fill=(40,28,19,170),width=4)
   for k in range(14):
    x=int(r.integers(W));d.arc((x,y+5,x+int(r.integers(30,90)),y+40),-30,35,fill=(192,132,79,60),width=2)
 else:
  for n in range(12000):
   x=int(r.integers(W));y=int(r.integers(W));R=int(r.integers(1,7));d.ellipse((x,y,x+R,y+R),fill=(67,48,41,int(r.integers(40,190))))
 im.save(T/name,optimize=True)
# Key CC0 pack integration manifest separate. Our generated models are originals, not downloads.
(ROOT/'docs/MODEL_LICENSES_V04.md').write_text('''# Model asset provenance — Aurora v0.4\n\nAll `assets/models/*_v04.glb` models and `*_v04.png` ground materials in this archive were generated originally with `/tools/build_detail_assets_v04.py` and may be used commercially. They are NOT falsely labeled as Quaternius assets.\n\nThe following external packs were verified CC0 and are recommended when replacing procedural geometry with professionally modelled assets:\n- Quaternius Stylized Nature MegaKit (116 models): https://quaternius.com/packs/stylizednaturemegakit.html\n- KayKit Forest Nature: https://kaylousberg.itch.io/kaykit-forest\n\nNo external downloaded models are included in this archive.\n''',encoding='utf8')
# include reproducible generator
shutil.copy2(__file__, ROOT/'tools/build_detail_assets_v04.py')
print('New model count',len(list(M.glob('*_v04.glb'))),'project MB',sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())/1048576)
