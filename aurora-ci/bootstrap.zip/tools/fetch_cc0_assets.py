#!/usr/bin/env python3
"""Download publicly available CC0 meshes for Aurora v0.5.
Source: https://github.com/agentkaerf/FreeModels (original work Quaternius),
        https://github.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0
Needs Internet. Designed for independent repeatable developer/CI use.
"""
from pathlib import Path
import json, urllib.request, urllib.parse, shutil, time, colorsys
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/cc0_nature';OUT.mkdir(exist_ok=True,parents=True)
HERO=ROOT/'assets/cc0_hero';HERO.mkdir(exist_ok=True,parents=True)
BASE='https://raw.githubusercontent.com/agentkaerf/FreeModels/main/Stylized%20Nature%20MegaKit%5BStandard%5D/glTF/'
CHAR_BASE='https://raw.githubusercontent.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0/main/addons/kaykit_character_pack_adventures/Characters/gltf/'

NATURE=['CommonTree_1','CommonTree_2','CommonTree_3','CommonTree_4','CommonTree_5',
        'Pine_1','Pine_2','Pine_3','Pine_4','Pine_5','Fern_1','Rock_Medium_1','Rock_Medium_2','Bush_Common']

def download(base,filename,directory):
    destination=directory/filename
    if destination.exists() and destination.stat().st_size: return destination
    request=urllib.request.Request(base+urllib.parse.quote(filename),headers={'User-Agent':'AuroraCC0Fetcher/1.0'})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(request,timeout=75) as r, open(destination.with_suffix(destination.suffix+'.partial'),'wb') as f:
                shutil.copyfileobj(r,f)
            destination.with_suffix(destination.suffix+'.partial').replace(destination)
            print('  fetched',filename,destination.stat().st_size,flush=True)
            return destination
        except Exception as e:
            if attempt==3: raise RuntimeError(f'Cannot obtain CC0 asset {filename}: {e}') from e
            time.sleep(1+attempt)

for name in NATURE:
    source=download(BASE,name+'.gltf',OUT)
    data=json.loads(source.read_text())
    used=[row['uri'] for row in data.get('buffers',[]) + data.get('images',[]) if 'uri' in row]
    for dep in used: download(BASE,dep,OUT)

# Quaternius trees are green by default. Recolor leaf mask texture only,
# retaining the UV mapping, opacity, normal maps and professionally sculpted meshes.
leaf=OUT/'Leaves_NormalTree_C.png'
if leaf.exists():
    img=Image.open(leaf).convert('RGBA')
    variants=[('Gold',36/360),('Amber',27/360),('Ruby',11/360)]
    for tag,hue in variants:
        pixels=img.copy()
        arr=pixels.load()
        for y in range(pixels.height):
            for x in range(pixels.width):
                r,g,b,a=arr[x,y]
                if a<9: continue
                h,s,v=colorsys.rgb_to_hsv(r/255,g/255,b/255)
                # Only recolor saturated leaf patches, not brown bark.
                if s>.13:
                    hue_shift=hue+(h-.25)*.27
                    nr,ng,nb=colorsys.hsv_to_rgb(hue_shift%1,max(.37,s),min(1,v*1.04+.02))
                    arr[x,y]=(int(nr*255),int(ng*255),int(nb*255),a)
        pixels.save(OUT/f'Leaves_NormalTree_C_{tag}.png',optimize=True)
    for i,tag in enumerate(['Gold','Amber','Ruby','Gold','Amber'],start=1):
        original=json.loads((OUT/f'CommonTree_{i}.gltf').read_text())
        for row in original.get('images',[]):
            if row.get('uri')=='Leaves_NormalTree_C.png':
                row['uri']=f'Leaves_NormalTree_C_{tag}.png'
        (OUT/f'AutumnTree_{tag}_{i}.gltf').write_text(json.dumps(original,ensure_ascii=False),encoding='utf8')

# A genuinely rigged character with 75+ clips, rather than assembled cubes.
# Free tier of KayKit, CC0, no attribution required.
download(CHAR_BASE,'Rogue_Hooded.glb',HERO)
(OUT/'LICENSE_SOURCE.txt').write_text('Quaternius Stylized Nature MegaKit [Standard], CC0-1.0. https://quaternius.com/packs/stylizednaturemegakit.html\n',encoding='utf8')
(HERO/'LICENSE_SOURCE.txt').write_text('KayKit Character Pack: Adventurers [Free], CC0-1.0. https://github.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0\n',encoding='utf8')
print('CC0 assets ready:',len(list(OUT.iterdir())),'nature files; hero', (HERO/'Rogue_Hooded.glb').stat().st_size)
