extends Node3D

# Three independently built locations modeled on the supplied reference video.
const BIRCH_GOLD := preload("res://assets/models/birch_gold_v04.glb")
const MAPLE_AMBER := preload("res://assets/models/maple_amber_v04.glb")
const MAPLE_RUBY := preload("res://assets/models/maple_ruby_v04.glb")
const BIRCH_PALE := preload("res://assets/models/birch_pale_v04.glb")
const SNOW_PINE := preload("res://assets/models/pine_snow_v04.glb")
const DARK_PINE := preload("res://assets/models/pine_dark_v04.glb")
const FERN := preload("res://assets/models/fern_broad_v04.glb")
const ROCK := preload("res://assets/models/boulder_moss_v04.glb")
const ICE_ROCK := preload("res://assets/models/boulder_snow_v04.glb")
const CABIN := preload("res://assets/models/snow_cabin.glb")
const TOADSTOOL := preload("res://assets/models/toadstool.glb")
const AUTUMN_TEX := preload("res://assets/textures/autumn_ground_v04.png")
const SNOW_TEX := preload("res://assets/textures/snow_ground_v04.png")
const WOOD_TEX := preload("res://assets/textures/cabin_wood_v04.png")
const PATH_TEX := preload("res://assets/textures/dirt_path_v04.png")
const AURORA_SHADER := preload("res://shaders/aurora.gdshader")

var biome := "autumn"
var action_position := Vector3(0.0, 0.0, -45.0)
var action_caption := "Идти к северному сиянию"
var next_biome := "winter"
var rng := RandomNumberGenerator.new()

func build(target: String) -> void:
    for child in get_children():
        remove_child(child)
        child.queue_free()
    biome = target
    rng.seed = 1849
    match biome:
        "winter":
            _environment(Color("031027"), Color("034C6A"), Color("143D51"), 0.013, 0.75)
            _build_winter()
        "cabin":
            _environment(Color("202B3C"), Color("8A6250"), Color("3D332F"), 0.0, 0.78)
            _build_cabin_interior()
        _:
            biome = "autumn"
            _environment(Color("6F9CB4"), Color("F3D59F"), Color("A18D69"), 0.014, 2.0)
            _build_autumn()

func _environment(top_color: Color, horizon_color: Color, fog_color: Color, fog_density: float, sun_energy: float) -> void:
    var world_env := get_node_or_null("../SafeEnvironment") as WorldEnvironment
    if world_env == null:
        world_env = WorldEnvironment.new()
        world_env.name = "Atmosphere"
        add_child(world_env)
    var env := Environment.new()
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = top_color
    sky_mat.sky_horizon_color = horizon_color
    sky_mat.ground_bottom_color = fog_color
    sky_mat.ground_horizon_color = horizon_color
    sky_mat.use_debanding = true
    sky.sky_material = sky_mat
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    env.ambient_light_energy = 0.94 if biome == "autumn" else 0.67
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = fog_density > 0.001
    env.fog_light_color = fog_color
    env.fog_density = fog_density
    world_env.environment = env
    var sun := DirectionalLight3D.new()
    sun.name = "SunOrMoon"
    sun.rotation_degrees = Vector3(-22, -38, -8) if biome == "autumn" else Vector3(-55, -25, 2)
    sun.light_color = Color("FFE0A6") if biome == "autumn" else Color("8BC9E7")
    sun.light_energy = sun_energy
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 45.0
    add_child(sun)

func _material(color: Color, tex: Texture2D = null, tile: float = 1.0) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 1.0
    if tex != null:
        mat.albedo_texture = tex
        mat.uv1_scale = Vector3(tile, tile, 1)
        mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    return mat

func _box(pos: Vector3, dimensions: Vector3, material: Material, parent: Node3D = null) -> MeshInstance3D:
    var mesh_node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    mesh_node.mesh = mesh
    mesh_node.material_override = material
    mesh_node.position = pos
    if parent == null:
        add_child(mesh_node)
    else:
        parent.add_child(mesh_node)
    return mesh_node

func _sphere(pos: Vector3, scale_value: Vector3, material: Material) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.mesh = SphereMesh.new()
    node.position = pos
    node.scale = scale_value
    node.material_override = material
    add_child(node)
    return node

func _model(resource: PackedScene, pos: Vector3, size: float = 1.0, yaw: float = 0.0, collidable := false) -> Node3D:
    var instance: Node3D = resource.instantiate()
    if biome != "cabin":
        pos.y += _terrain_height(pos.x, pos.z)
    instance.position = pos
    instance.rotation.y = yaw
    instance.scale = Vector3.ONE * size
    add_child(instance)
    if collidable:
        var collider := StaticBody3D.new()
        var shape := CollisionShape3D.new()
        var cylinder := CylinderShape3D.new()
        cylinder.radius = 0.35
        cylinder.height = 7.0
        shape.shape = cylinder
        shape.position.y = 3.5
        collider.position = pos
        collider.scale = Vector3.ONE * size
        collider.add_child(shape)
        add_child(collider)
    return instance

func _terrain_height(x: float, z: float) -> float:
    if biome == "cabin":
        return 0.0
    var center_x := sin(-z * 0.085) * (2.9 if biome == "autumn" else 1.6)
    var offset: float = absf(x - center_x)
    var blend: float = smoothstep(2.9, 15.0, offset)
    var ridge: float = sin(x * 0.105 + z * 0.071) * 0.62 + sin(x * .062 - z * .11) * .35
    return maxf(-0.15, (ridge + 0.3) * blend * (1.0 if biome == "autumn" else 1.3))

func _flat_land(texture_: Texture2D, tint: Color, width_: float = 180.0) -> void:
    # Contiguous, shaded terrain. The winding trail is mixed INTO the floor shader;
    # there are no elevated box tiles or visible rectangular seams.
    var ground := MeshInstance3D.new()
    ground.name = "ContinuousForestFloor"
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    var steps := 112 if biome != "cabin" else 8
    var half := width_ * 0.5
    for z_idx in range(steps):
        for x_idx in range(steps):
            var x0 := -half + width_ * float(x_idx) / float(steps)
            var x1 := -half + width_ * float(x_idx + 1) / float(steps)
            var z0 := -half + width_ * float(z_idx) / float(steps)
            var z1 := -half + width_ * float(z_idx + 1) / float(steps)
            var p0 := Vector3(x0, _terrain_height(x0,z0), z0)
            var p1 := Vector3(x1, _terrain_height(x1,z0), z0)
            var p2 := Vector3(x1, _terrain_height(x1,z1), z1)
            var p3 := Vector3(x0, _terrain_height(x0,z1), z1)
            for vertex in [p0,p2,p1,p0,p3,p2]:
                var center_x := sin(-vertex.z * 0.085) * (2.9 if biome == "autumn" else 1.6)
                var distance_to_trail := absf(vertex.x - center_x)
                var trail_mask := 0.0 if biome == "cabin" else 1.0 - smoothstep(1.9, 4.4, distance_to_trail)
                surface.set_color(Color(trail_mask, 0.0, 0.0, 1.0))
                surface.set_uv(Vector2(vertex.x / 7.0, vertex.z / 7.0))
                surface.add_vertex(vertex)
    surface.generate_normals()
    var mesh: ArrayMesh = surface.commit()
    ground.mesh = mesh
    if biome == "cabin":
        ground.material_override = _material(tint, texture_, 1.0)
    else:
        var terrain_material := ShaderMaterial.new()
        terrain_material.shader = preload("res://shaders/terrain_blend.gdshader")
        terrain_material.set_shader_parameter("ground_tex", texture_)
        terrain_material.set_shader_parameter("trail_tex", SNOW_TEX if biome == "winter" else PATH_TEX)
        terrain_material.set_shader_parameter("winter", biome == "winter")
        ground.material_override = terrain_material
    add_child(ground)
    var body := StaticBody3D.new()
    body.name = "TerrainCollision"
    var collider := CollisionShape3D.new()
    collider.shape = mesh.create_trimesh_shape()
    body.add_child(collider)
    add_child(body)

func _footpath(length_: float, snowy: bool) -> void:
    var mat := _material(Color("C7B69D") if snowy else Color("DDAB62"), SNOW_TEX if snowy else PATH_TEX, 0.9)
    for n in range(int(length_ / 2.0)):
        var z := -float(n) * 2.0
        var x := sin(float(n) * 0.17) * (1.6 if snowy else 2.9)
        var x_next := sin(float(n + 1) * 0.17) * (1.6 if snowy else 2.9)
        var segment := _box(Vector3(x, _terrain_height(x,z) + 0.035, z), Vector3(4.25, 0.065, 2.3), mat)
        segment.rotation.y = atan2(x_next - x, -2.0)

func _nature_scene(name: String, fallback: PackedScene) -> PackedScene:
    var path := "res://assets/cc0_nature/" + name + ".gltf"
    if ResourceLoader.exists(path):
        var loaded := load(path) as PackedScene
        if loaded != null:
            return loaded
    return fallback

func _build_autumn() -> void:
    _flat_land(AUTUMN_TEX, Color("F8EBCA"))
    var trees: Array[PackedScene] = [_nature_scene("AutumnTree_Gold_1", BIRCH_GOLD), _nature_scene("AutumnTree_Amber_2", MAPLE_AMBER), _nature_scene("AutumnTree_Ruby_3", MAPLE_RUBY), _nature_scene("AutumnTree_Gold_4", BIRCH_PALE), _nature_scene("AutumnTree_Amber_5", MAPLE_AMBER)]
    for i in range(170):
        var x := rng.randf_range(-70, 70)
        var z := rng.randf_range(-82, 41)
        var path_x := sin(-z * 0.085) * 2.9
        if absf(x - path_x) < 4.0 and z < 3.0:
            x += 6.5 if x >= 0 else -6.5
        if absf(x) < 5.0 and absf(z) < 5.0:
            x += 6.0
        _model(trees[i % trees.size()], Vector3(x, -0.06, z), rng.randf_range(1.15, 1.90), rng.randf_range(-PI, PI), i % 4 == 0)
    for i in range(320):
        var x := rng.randf_range(-59, 59)
        var z := rng.randf_range(-79, 36)
        _model(_nature_scene("Fern_1", FERN) if i % 3 else _nature_scene("Rock_Medium_1", ROCK), Vector3(x, 0.02, z), rng.randf_range(0.45, 1.25), rng.randf_range(0, TAU))
    for i in range(92):
        _model(TOADSTOOL, Vector3(rng.randf_range(-48, 48), 0.01, rng.randf_range(-72, 20)), rng.randf_range(0.4, 1.0))
    _scatter_ground(true)
    _add_grass_bed(true)
    _sunbeams()
    _particles(false)
    _gateway(Vector3(0, 0, -47), Color("EAD893"))
    action_position = Vector3(0, 0, -45)
    action_caption = "Перейти в снежные горы"
    next_biome = "winter"

func _build_winter() -> void:
    _flat_land(SNOW_TEX, Color("C7ECF3"))
    for i in range(145):
        var x := rng.randf_range(-69, 69)
        var z := rng.randf_range(-77, 40)
        var path_x := sin(-z * 0.085) * 1.6
        if absf(x - path_x) < 4.3 and z < 3.0:
            x += 6.5 if x >= 0 else -6.5
        if absf(x) < 8 and z < -39 and z > -57:
            x += 11.0
        _model(_nature_scene("Pine_" + str((i % 5) + 1), SNOW_PINE) if i % 5 else DARK_PINE, Vector3(x, -0.06, z), rng.randf_range(1.3, 2.05), rng.randf_range(-PI, PI), i % 4 == 0)
    for i in range(100):
        _model(ICE_ROCK, Vector3(rng.randf_range(-67, 67), 0.0, rng.randf_range(-80, 30)), rng.randf_range(0.36, 1.45), rng.randf_range(-PI, PI))
    _build_mountains()
    _add_grass_bed(false)
    _make_aurora()
    _particles(true)
    _model(CABIN, Vector3(0, 0, -47), 1.20)
    var window_glow := OmniLight3D.new()
    window_glow.position = Vector3(1.0, 3.1, -43.0)
    window_glow.light_color = Color("FBC17B")
    window_glow.light_energy = 2.1
    window_glow.omni_range = 14.0
    window_glow.shadow_enabled = false
    add_child(window_glow)
    action_position = Vector3(0, 0, -41.5)
    action_caption = "Войти в тёплую хижину"
    next_biome = "cabin"

func _build_mountains() -> void:
    var mat := StandardMaterial3D.new()
    mat.vertex_color_use_as_albedo = true
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.roughness = 1.0
    for layer in range(3):
        var surface := SurfaceTool.new()
        surface.begin(Mesh.PRIMITIVE_TRIANGLES)
        var z := -74.0 - 17.0 * layer
        var step := 7.0
        for i in range(34):
            var x0 := -126.0 + i * step
            var x1 := x0 + step
            var h0 := 10.0 + 13.0 * (0.5 + 0.5 * sin(i * 1.77 + layer * 2.6)) + rng.randf_range(-2,4)
            var h1 := 10.0 + 13.0 * (0.5 + 0.5 * sin((i+1) * 1.77 + layer * 2.6)) + rng.randf_range(-2,4)
            var peak := Vector3((x0+x1)*0.5, maxf(h0,h1)+rng.randf_range(4,11), z-rng.randf_range(2,8))
            var c := Color("253A4C") if layer == 0 else Color("36546D")
            var col := c.lerp(Color("7CA9BA"), float(layer) * .20)
            var p0 := Vector3(x0,-.5,z+3)
            var p1 := Vector3(x1,-.5,z+3)
            for p in [p0,peak,p1]:
                surface.set_color(col)
                surface.add_vertex(p)
            for p in [Vector3(x0+2,h0*.7,z+1),peak,Vector3(x1-2,h1*.7,z+1)]:
                surface.set_color(Color("C8E9F4") if layer < 2 else Color("9BC4D3"))
                surface.add_vertex(p)
        var mountain := MeshInstance3D.new()
        mountain.name = "JaggedSnowyMountainRange"
        mountain.mesh = surface.commit()
        mountain.material_override = mat
        add_child(mountain)

func _make_aurora() -> void:
    var hues := [Color("21E4A4"), Color("4AEF9E"), Color("34BEE4"), Color("65E5A4"), Color("77B0D4")]
    for curtain in range(6):
        var surface := SurfaceTool.new()
        surface.begin(Mesh.PRIMITIVE_TRIANGLES)
        for i in range(110):
            var u0 := float(i) / 110.0
            var u1 := float(i + 1) / 110.0
            var x0 := -64.0 + u0 * 128.0
            var x1 := -64.0 + u1 * 128.0
            var y0 := 25.0 + sin(u0 * 19.0 + curtain) * 3.0
            var y1 := 25.0 + sin(u1 * 19.0 + curtain) * 3.0
            var z0 := -65.0 - curtain * 5.0
            var strip_vertices: Array = [
                [Vector3(x0, y0 - 13, z0), Vector2(u0, 1)],
                [Vector3(x1, y1 + 11, z0), Vector2(u1, 0)],
                [Vector3(x0, y0 + 11, z0), Vector2(u0, 0)],
                [Vector3(x0, y0 - 13, z0), Vector2(u0, 1)],
                [Vector3(x1, y1 - 13, z0), Vector2(u1, 1)],
                [Vector3(x1, y1 + 11, z0), Vector2(u1, 0)]
            ]
            for vertex in strip_vertices:
                surface.set_uv(vertex[1])
                surface.add_vertex(vertex[0])
        var mesh := surface.commit()
        var node := MeshInstance3D.new()
        node.mesh = mesh
        var mat := ShaderMaterial.new()
        mat.shader = AURORA_SHADER
        mat.set_shader_parameter("glow_color", hues[curtain % hues.size()])
        mat.set_shader_parameter("motion_speed", 0.17 + curtain * 0.035)
        node.material_override = mat
        node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(node)

func _particles(is_snow: bool) -> void:
    var particles := CPUParticles3D.new()
    particles.name = "FallingSnow" if is_snow else "FallingLeaves"
    particles.amount = 160 if is_snow else 110
    particles.lifetime = 8.0
    particles.preprocess = 8.0
    particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    particles.emission_box_extents = Vector3(26, 7, 26)
    particles.position = Vector3(0, 8, -16)
    particles.direction = Vector3(0.35, -1, 0.15)
    particles.spread = 14.0
    particles.gravity = Vector3(0.12, -0.65 if is_snow else -1.2, 0.11)
    particles.initial_velocity_min = 0.2
    particles.initial_velocity_max = 1.3
    particles.scale_amount_min = 0.5
    particles.scale_amount_max = 1.1
    var quad := QuadMesh.new()
    quad.size = Vector2(0.08, 0.08) if is_snow else Vector2(0.12, 0.18)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color("EBF8FF") if is_snow else Color("EDAB46")
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    quad.material = mat
    particles.mesh = quad
    particles.emitting = true
    add_child(particles)

func _scatter_ground(is_autumn: bool) -> void:
    # Thousands of leaf-shaped meshes; no longer square ground stickers.
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    var outline := [Vector3(0, 0, -.29), Vector3(.13, 0, -.09), Vector3(.19, 0, .04), Vector3(.065, 0, .19), Vector3(0, .015, .35), Vector3(-.06, 0, .19), Vector3(-.18, 0, .02), Vector3(-.13, 0, -.09)]
    for i in range(outline.size()):
        surface.set_uv(Vector2(0.5, 0.5))
        surface.add_vertex(Vector3.ZERO)
        surface.set_uv(Vector2(1, 0))
        surface.add_vertex(outline[i])
        surface.set_uv(Vector2(0, 1))
        surface.add_vertex(outline[(i + 1) % outline.size()])
    surface.generate_normals()
    var mesh := surface.commit()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mat.vertex_color_use_as_albedo = true
    mat.roughness = 1.0
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mesh.surface_set_material(0, mat)
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = true
    multi.mesh = mesh
    multi.instance_count = 8400
    for i in range(multi.instance_count):
        var x := rng.randf_range(-67, 67)
        var z := rng.randf_range(-81, 33)
        var f := rng.randf_range(.54, 1.40)
        var orient := Basis(Vector3.UP, rng.randf_range(0, TAU)).scaled(Vector3(f, 1, f))
        multi.set_instance_transform(i, Transform3D(orient, Vector3(x, _terrain_height(x,z) + .065, z)))
        multi.set_instance_color(i, Color.from_hsv(rng.randf_range(.045, .15), rng.randf_range(.64,.95), rng.randf_range(.63, .96)))
    var leaf_litter := MultiMeshInstance3D.new()
    leaf_litter.name = "ShapedAutumnLeaves"
    leaf_litter.multimesh = multi
    add_child(leaf_litter)

func _add_grass_bed(autumn: bool) -> void:
    # Asymmetric tapered grass blades in a single mesh reused via MultiMesh.
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    for b in range(7):
        var angle := float(b) * TAU / 7.0
        var h := .43 + .15 * sin(float(b) * 2.1)
        var tip := Vector3(sin(angle) * .20, h, cos(angle) * .2)
        var side := Vector3(cos(angle) * .07, 0, -sin(angle) * .07)
        var p0 := -side
        var p1 := side
        var p2 := Vector3(0, h * .45, 0) + side * .56
        var p3 := tip
        var p4 := Vector3(0, h * .45, 0) - side * .56
        for v in [p0,p1,p2,p0,p2,p4,p4,p2,p3]:
            surface.set_uv(Vector2(v.x + .5, v.y))
            surface.add_vertex(v)
    surface.generate_normals()
    var mesh := surface.commit()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mat.vertex_color_use_as_albedo = true
    mat.roughness = 1.0
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mesh.surface_set_material(0, mat)
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    multi.use_colors = true
    multi.mesh = mesh
    multi.instance_count = 4100 if autumn else 700
    for i in range(multi.instance_count):
        var x := rng.randf_range(-55, 55)
        var z := rng.randf_range(-75, 32)
        var path_center := sin(-z * .085) * (2.9 if autumn else 1.6)
        if absf(x - path_center) < 4.0:
            x += 4.6 if x > path_center else -4.6
        var f := rng.randf_range(.6, 1.6)
        var basis := Basis(Vector3.UP, rng.randf_range(0,TAU)).scaled(Vector3(f,f,rng.randf_range(.7,1.1)))
        multi.set_instance_transform(i, Transform3D(basis, Vector3(x,_terrain_height(x,z),z)))
        multi.set_instance_color(i, Color.from_hsv(rng.randf_range(.17,.27) if autumn else .48, rng.randf_range(.38,.64), rng.randf_range(.48,.84)))
    var grass := MultiMeshInstance3D.new()
    grass.name = "OrganicBladedGrass"
    grass.multimesh = multi
    add_child(grass)

func _sunbeams() -> void:
    # Subtle soft beams enhance the warm low sun without costly volumetric effects.
    var mat := StandardMaterial3D.new()
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.albedo_color = Color(1.0,.83,.54,.065)
    mat.no_depth_test = false
    for i in range(9):
        var beam := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(rng.randf_range(2.0,3.3),22.0,0.018)
        beam.mesh = box
        beam.material_override = mat
        beam.position = Vector3(-18.0 + i * 4.2,10.1,-18.0-rng.randf_range(0,28))
        beam.rotation_degrees = Vector3(5,30,-22)
        beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(beam)

func _gateway(where: Vector3, light_color: Color) -> void:
    var wood := _material(Color("4D3C32"))
    var gold := _material(Color("C89B59"))
    for x in [-1.5, 1.5]:
        _box(where + Vector3(x, 2.25, 0), Vector3(0.38, 4.5, 0.43), wood)
        _box(where + Vector3(x, 4.38, 0), Vector3(0.7, 0.27, 0.65), gold)
    _box(where + Vector3(0, 4.6, 0), Vector3(3.6, 0.38, 0.59), wood)
    var glow := OmniLight3D.new()
    glow.position = where + Vector3(0, 3.5, 0)
    glow.light_color = light_color
    glow.light_energy = 1.6
    glow.omni_range = 8.0
    add_child(glow)

func _build_cabin_interior() -> void:
    _flat_land(WOOD_TEX, Color("D4B69A"), 80)
    var floor_mat := _material(Color("97745A"), WOOD_TEX, 2.4)
    var wall_mat := _material(Color("765039"), WOOD_TEX, 1.7)
    var dark := _material(Color("513622"))
    var warm := _material(Color("F7CB72"))
    var red := _material(Color("9C3C30"))
    var turquoise := _material(Color("3E7E79"))
    _box(Vector3(0, 0.03, 0), Vector3(16, 0.20, 15), floor_mat)
    _box(Vector3(0, 4.1, -7.6), Vector3(16.5, 8.2, 0.5), wall_mat)
    _box(Vector3(-8.1, 4.1, 0), Vector3(0.5, 8.2, 15.6), wall_mat)
    _box(Vector3(8.1, 4.1, 0), Vector3(0.5, 8.2, 15.6), wall_mat)
    # Roof beams; no front wall, so the follow camera can look inside unobstructed.
    for x in [-7.0, -4.0, -1.0, 2.0, 5.0, 7.2]:
        _box(Vector3(x, 7.7, 0), Vector3(.38, .37, 15), dark)
    for side in [-1, 1]:
        _box(Vector3(side * 3.6, 0.09, 0), Vector3(0.38, 0.12, 13), dark)
    # Hearth and animated golden fireplace lighting.
    _box(Vector3(0, 1.55, -7.2), Vector3(3.8, 3.1, 1.7), _material(Color("55534C")))
    _box(Vector3(0, 0.83, -6.14), Vector3(2.2, 1.5, 0.26), dark)
    _sphere(Vector3(0, 0.88, -6.05), Vector3(.45, .82, .23), _material(Color("F78B24")))
    _sphere(Vector3(.16, 1.14, -6.00), Vector3(.21, .57, .15), warm)
    var firelight := OmniLight3D.new()
    firelight.position = Vector3(0, 2.45, -5.4)
    firelight.light_color = Color("FFA653")
    firelight.light_energy = 2.8
    firelight.omni_range = 17.0
    add_child(firelight)
    # Tables, food baskets, books, rugs, stools, shelves and supplies.
    _box(Vector3(-3.2, 1.1, -2.5), Vector3(3.4, .21, 2.0), dark)
    for x in [-4.5, -2.0]:
        for z in [-3.2, -1.8]:
            _box(Vector3(x, .52, z), Vector3(.25, 1.03, .25), dark)
    _box(Vector3(-2.0, .8, 1.3), Vector3(1.35, .25, 1.1), dark)
    for z in [-.9, 2.0, 4.8]:
        _box(Vector3(6.8, 2.9, z), Vector3(2.1, .22, 1.4), dark)
        _box(Vector3(6.85, 1.7, z), Vector3(2.0, .19, 1.4), dark)
    for i in range(22):
        var x := 6.4 + rng.randf_range(-.4, .4)
        var z := rng.randf_range(-1.5, 5.8)
        _box(Vector3(x, 1.85 + (1.2 if i % 2 else 0), z), Vector3(rng.randf_range(.12, .25), .62, .46), red if i % 3 else turquoise)
    _box(Vector3(2.4, 0.13, 0.3), Vector3(3.8, .035, 5.2), red)
    _box(Vector3(-5.75, 1.2, 1.5), Vector3(2.5, 1.5, 5.2), dark)
    _box(Vector3(-5.75, 2.0, 1.5), Vector3(2.6, .45, 5.3), red)
    _box(Vector3(-5.6, 2.5, 3.3), Vector3(2.4, .46, 1.1), warm)
    action_position = Vector3(0, 0, 6.4)
    action_caption = "Выйти к северному сиянию"
    next_biome = "winter"
