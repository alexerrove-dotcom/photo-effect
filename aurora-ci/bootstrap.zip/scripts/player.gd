extends CharacterBody3D

# Fully procedural, animated third-person adventurer (Godot 4.4+).
const WALK_SPEED := 5.2
const RUN_SPEED := 8.4
const JUMP_SPEED := 6.0
const GRAVITY := 18.0

var controls: Variant = null
var movement_enabled := false
var jump_requested := false
var run_pressed := false
var camera_yaw := 0.0
var camera_pitch := 0.22
var camera_distance := 5.75
var walk_phase := 0.0
var look_node: Node3D
var left_arm: Node3D
var right_arm: Node3D
var left_leg: Node3D
var right_leg: Node3D
var cape: MeshInstance3D
var cam: Camera3D
var camera_target := Vector3.ZERO
var cape_material: StandardMaterial3D
var external_anim: AnimationPlayer = null
var has_cc0_hero := false
var current_clip: StringName = &""


func _ready() -> void:
    floor_snap_length = 0.45
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.35
    capsule.height = 1.92
    shape.shape = capsule
    shape.position.y = 0.99
    add_child(shape)
    _build_character()
    # Use a camera placed in the scene: even if this script fails, it remains active.
    cam = get_parent().get_node_or_null("SafeFollowCamera") as Camera3D
    if cam == null:
        cam = Camera3D.new()
        cam.name = "SafeFollowCamera"
        get_parent().add_child(cam)
    cam.current = true
    cam.fov = 67.0
    cam.near = 0.1
    cam.global_position = global_position + Vector3(0, 3.15, 5.75)
    cam.look_at(global_position + Vector3(0, 1.5, 0), Vector3.UP)
    camera_target = cam.global_position

func _material(color: Color, metallic := 0.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.86
    m.metallic = metallic
    return m

func _piece(parent: Node3D, mesh: Mesh, name_: String, pos: Vector3, scale_: Vector3, color: Color) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    node.name = name_
    node.mesh = mesh
    node.position = pos
    node.scale = scale_
    node.material_override = _material(color)
    parent.add_child(node)
    return node

const HERO_BODY := preload("res://assets/models/hero_torso_v04.glb")
const HERO_ARM := preload("res://assets/models/hero_arm_v04.glb")
const HERO_LEG := preload("res://assets/models/hero_leg_v04.glb")

func _build_character() -> void:
    look_node = Node3D.new()
    look_node.name = "AnimatedCC0TravellerV05"
    add_child(look_node)
    # CC0 rigged animated hero takes precedence over the former handmade figure.
    # Fallback remains so the source project still opens without downloading assets.
    var rig_path := "res://assets/cc0_hero/Rogue_Hooded.glb"
    if ResourceLoader.exists(rig_path):
        var rig := load(rig_path) as PackedScene
        if rig != null:
            var character := rig.instantiate() as Node3D
            character.name = "KayKitCC0RogueHooded"
            look_node.add_child(character)
            external_anim = _find_anim(character)
            has_cc0_hero = true
            _choose_external_animation("idle")
    if not has_cc0_hero:
        var torso: Node3D = HERO_BODY.instantiate()
        torso.name = "OriginalTravellerFallback"
        look_node.add_child(torso)
    left_arm = Node3D.new()
    left_arm.position = Vector3(-0.47,1.65,0.0)
    look_node.add_child(left_arm)
    right_arm = Node3D.new()
    right_arm.position = Vector3(0.47,1.65,0.0)
    look_node.add_child(right_arm)
    var left_arm_mesh: Node3D = HERO_ARM.instantiate()
    var right_arm_mesh: Node3D = HERO_ARM.instantiate()
    if not has_cc0_hero:
        left_arm.add_child(left_arm_mesh)
        right_arm.add_child(right_arm_mesh)
    left_arm_mesh.rotation.z = -0.05
    right_arm_mesh.rotation.z = 0.05
    left_leg = Node3D.new()
    left_leg.position = Vector3(-0.20,.90,0.0)
    look_node.add_child(left_leg)
    right_leg = Node3D.new()
    right_leg.position = Vector3(0.20,.90,0.0)
    look_node.add_child(right_leg)
    if not has_cc0_hero:
        left_leg.add_child(HERO_LEG.instantiate())
        right_leg.add_child(HERO_LEG.instantiate())
    cape = MeshInstance3D.new()
    cape.name = "WovenSapphireCape"
    cape_material = _material(Color("1D4AA0"))
    cape_material.cull_mode = BaseMaterial3D.CULL_DISABLED
    cape.material_override = cape_material
    look_node.add_child(cape)
    _update_cape(0.0,0.0)

func _find_anim(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node as AnimationPlayer
    for child in node.get_children():
        var found := _find_anim(child)
        if found != null:
            return found
    return null

func _choose_external_animation(action: String) -> void:
    if external_anim == null:
        return
    var preferred: Array[String] = []
    match action:
        "run":
            preferred = ["Running_A", "Running_B", "Run"]
        "walk":
            preferred = ["Walking_A", "Walking_B", "Walking_C", "Walk"]
        "jump":
            preferred = ["Jump_Start", "Jump", "Jump_Idle"]
        _:
            preferred = ["Idle_A", "Idle_B", "Idle"]
    var clips := external_anim.get_animation_list()
    for wanted in preferred:
        for clip in clips:
            var name_text: String = String(clip)
            if name_text == wanted or name_text.ends_with("/" + wanted):
                if current_clip != clip:
                    external_anim.play(clip, 0.2)
                    current_clip = clip
                return

func _update_cape(time_value: float, speed_ratio: float) -> void:
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLES)
    var w := 18
    var h := 13
    var verts: Array[Vector3] = []
    for j in range(h + 1):
        var t := float(j) / h
        var halfwidth := lerpf(0.34, 0.81, t)
        for i in range(w + 1):
            var u := float(i) / w
            var ripple := sin(time_value * (2.5 + speed_ratio * 4.3) + u * 9.0 + t * 5.0) * (0.018 + t * 0.09)
            var x := (u * 2.0 - 1.0) * halfwidth
            var y := 1.93 - t * 1.60 + ripple * 0.25
            var z := 0.23 + t * (0.31 + speed_ratio * 0.38) + ripple
            verts.append(Vector3(x, y, z))
    for j in range(h):
        for i in range(w):
            var a := j * (w + 1) + i
            for idx in [a, a + w + 1, a + 1, a + 1, a + w + 1, a + w + 2]:
                var row := int(idx / (w + 1))
                var u := float(idx % (w + 1)) / w
                surface.set_uv(Vector2(u, float(row) / h))
                surface.add_vertex(verts[idx])
    surface.generate_normals()
    cape.mesh = surface.commit()

func request_jump() -> void:
    jump_requested = true

func rotate_camera(delta: Vector2) -> void:
    camera_yaw -= delta.x * 0.006
    camera_pitch = clampf(camera_pitch + delta.y * 0.004, -0.16, 0.77)

func teleport_to(location: Vector3) -> void:
    global_position = location
    velocity = Vector3.ZERO
    walk_phase = 0
    if is_instance_valid(cam):
        cam.global_position = global_position + Vector3(0, 3.15, 5.75)
        cam.look_at(global_position + Vector3(0, 1.57, 0), Vector3.UP)
        camera_target = cam.global_position

func _physics_process(delta: float) -> void:
    var move_vec := Vector2.ZERO
    if movement_enabled:
        move_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
        if controls != null:
            var stick: Vector2 = controls.get_move()
            if stick.length_squared() > move_vec.length_squared():
                move_vec = stick
    move_vec = move_vec.limit_length(1.0)
    var direction := Basis(Vector3.UP, camera_yaw) * Vector3(move_vec.x, 0, move_vec.y)
    var sprint := run_pressed or Input.is_action_pressed("run")
    var speed := RUN_SPEED if sprint else WALK_SPEED
    var target_velocity := direction * speed
    velocity.x = move_toward(velocity.x, target_velocity.x, delta * 26.0)
    velocity.z = move_toward(velocity.z, target_velocity.z, delta * 26.0)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif movement_enabled and (jump_requested or Input.is_action_just_pressed("jump")):
        velocity.y = JUMP_SPEED
    else:
        velocity.y = -0.3
    jump_requested = false
    move_and_slide()
    _update_camera_obstruction()
    var speed_ratio := clampf(Vector2(velocity.x, velocity.z).length() / RUN_SPEED, 0.0, 1.0)
    if direction.length_squared() > 0.01:
        var wanted := atan2(-direction.x, -direction.z)
        look_node.rotation.y = lerp_angle(look_node.rotation.y, wanted, delta * 12.0)
    walk_phase += speed_ratio * delta * 13.0
    if has_cc0_hero:
        if not is_on_floor():
            _choose_external_animation("jump")
        elif speed_ratio > .65:
            _choose_external_animation("run")
        elif speed_ratio > .075:
            _choose_external_animation("walk")
        else:
            _choose_external_animation("idle")
    else:
        left_leg.rotation.x = sin(walk_phase) * speed_ratio * 0.71
        right_leg.rotation.x = -sin(walk_phase) * speed_ratio * 0.71
        left_arm.rotation.x = -sin(walk_phase) * speed_ratio * 0.47
        right_arm.rotation.x = sin(walk_phase) * speed_ratio * 0.47
    look_node.position.y = abs(sin(walk_phase)) * 0.035 * speed_ratio
    _update_cape(float(Time.get_ticks_msec()) * 0.001, speed_ratio)

# PhysicsDirectSpaceState3D is only safe to query on the physics tick.
# v0.2 used it in _process(), which can leave the camera at the origin on Android.
func _update_camera_obstruction() -> void:
    var focus := global_position + Vector3(0, 1.57, 0)
    var orbit := Vector3(sin(camera_yaw) * cos(camera_pitch), sin(camera_pitch), cos(camera_yaw) * cos(camera_pitch))
    var destination := focus + orbit * camera_distance
    var query := PhysicsRayQueryParameters3D.create(focus, destination)
    query.exclude = [get_rid()]
    var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
    if not hit.is_empty():
        destination = (hit.position as Vector3) + (focus - hit.position).normalized() * 0.28
    camera_target = destination

func _process(delta: float) -> void:
    if not is_instance_valid(cam):
        return
    var focus := global_position + Vector3(0, 1.57, 0)
    # Rendering callback must never query the physics server.
    cam.global_position = cam.global_position.lerp(camera_target, minf(1.0, delta * 9.0))
    cam.look_at(focus, Vector3.UP)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP:
            camera_distance = maxf(3.4, camera_distance - 0.4)
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            camera_distance = minf(11.0, camera_distance + 0.4)
