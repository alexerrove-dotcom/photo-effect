extends Node3D

@onready var world: Variant = $World
@onready var hero: Variant = $Hero
@onready var hud: Variant = $Hud

var transitions := 0
var memories := {"autumn": 0, "winter": 0, "cabin": 0}
var total_memories := 0
var biome_memories := 0
var collected_ids: Dictionary = {}
var memory_positions := {
    "autumn": [Vector3(6, 1.2, -12), Vector3(-7, 1.2, -29), Vector3(4, 1.2, -41)],
    "winter": [Vector3(7, 1.2, -14), Vector3(-8, 1.2, -28), Vector3(7, 1.2, -40)],
    "cabin": [Vector3(-4, 1.2, -1.5), Vector3(3.5, 1.2, -3.7), Vector3(-1.8, 1.2, 3)],
}
var glowing_charms: Array[Node3D] = []

func _ready() -> void:
    get_window().content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
    _install_controls()
    _load_progress()
    # The full offline scene is rebuilt locally: no network or plugin dependencies.
    world.build("autumn")
    _set_fallback_for_world()
    _spawn_memories()
    hero.teleport_to(Vector3(0, 0.4, 8))
    hud.setup(self, hero)
    hero.controls = hud

func travel_to(place: String) -> void:
    if place == world.biome:
        return
    world.build(place)
    _set_fallback_for_world()
    _spawn_memories()
    _save_progress()
    transitions += 1
    match place:
        "winter":
            hero.teleport_to(Vector3(0, 0.4, 11.0))
        "cabin":
            hero.teleport_to(Vector3(0, 0.4, 5.0))
        _:
            hero.teleport_to(Vector3(0, 0.4, 8.0))
    hud.notify_scene_changed()

func use_portal() -> void:
    if hero.global_position.distance_to(world.action_position) <= 5.5:
        travel_to(world.next_biome)

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("interact"):
        use_portal()
    elif event.is_action_pressed("pause"):
        hud.show_start_menu(not hud.menu_open)
    elif event.is_action_pressed("scene_autumn"):
        travel_to("autumn")
    elif event.is_action_pressed("scene_winter"):
        travel_to("winter")
    elif event.is_action_pressed("scene_cabin"):
        travel_to("cabin")

func _install_controls() -> void:
    # Building the input map here avoids platform-specific .godot serialization.
    var keys := {
        "move_left": [KEY_A, KEY_LEFT],
        "move_right": [KEY_D, KEY_RIGHT],
        "move_forward": [KEY_W, KEY_UP],
        "move_back": [KEY_S, KEY_DOWN],
        "jump": [KEY_SPACE],
        "run": [KEY_SHIFT],
        "interact": [KEY_E],
        "pause": [KEY_ESCAPE],
        "scene_autumn": [KEY_1],
        "scene_winter": [KEY_2],
        "scene_cabin": [KEY_3],
    }
    for action_name in keys.keys():
        if not InputMap.has_action(action_name):
            InputMap.add_action(action_name, 0.2)
        for code in keys[action_name]:
            var key_event := InputEventKey.new()
            key_event.physical_keycode = code
            InputMap.action_add_event(action_name, key_event)

func _spawn_memories() -> void:
    glowing_charms.clear()
    var positions: Array = memory_positions.get(world.biome, [])
    for i in range(positions.size()):
        var memory_id: String = str(world.biome) + "-" + str(i)
        if collected_ids.has(memory_id):
            continue
        var node := Area3D.new()
        node.name = "Memory_" + str(i)
        node.position = positions[i]
        var shape := CollisionShape3D.new()
        var orb := SphereShape3D.new()
        orb.radius = 1.0
        shape.shape = orb
        node.add_child(shape)
        var core := MeshInstance3D.new()
        var gem := SphereMesh.new()
        gem.radius = 0.31
        gem.height = 0.62
        core.mesh = gem
        core.scale = Vector3(0.75, 1.26, 0.75)
        var gem_mat := StandardMaterial3D.new()
        gem_mat.albedo_color = Color("FFE1A1") if world.biome != "winter" else Color("8DFFE4")
        gem_mat.emission_enabled = true
        gem_mat.emission = gem_mat.albedo_color
        gem_mat.emission_energy_multiplier = 2.5
        core.material_override = gem_mat
        node.add_child(core)
        var lamp := OmniLight3D.new()
        lamp.light_color = gem_mat.albedo_color
        lamp.light_energy = 0.6
        lamp.omni_range = 3.2
        lamp.shadow_enabled = false
        node.add_child(lamp)
        node.body_entered.connect(_on_memory_entered.bind(memory_id, node))
        world.add_child(node)
        glowing_charms.append(node)
    _refresh_memories()

func _on_memory_entered(body: Node3D, memory_id: String, node: Area3D) -> void:
    if body != hero or collected_ids.has(memory_id):
        return
    collected_ids[memory_id] = true
    node.queue_free()
    glowing_charms.erase(node)
    _refresh_memories()
    _save_progress()

func _refresh_memories() -> void:
    total_memories = collected_ids.size()
    biome_memories = 0
    for key in collected_ids.keys():
        if str(key).begins_with(world.biome + "-"):
            biome_memories += 1
    if is_instance_valid(hud) and hud.has_method("set_memories"):
        hud.set_memories(biome_memories, total_memories)

func _process(delta: float) -> void:
    for charm in glowing_charms:
        if is_instance_valid(charm):
            charm.rotate_y(delta * 0.75)
            var visual := charm.get_node_or_null("MeshInstance3D") as MeshInstance3D
            if visual:
                visual.position.y = sin(Time.get_ticks_msec() * .002 + float(charm.get_instance_id() % 7)) * 0.17

func _save_progress() -> void:
    var save := ConfigFile.new()
    save.set_value("explorer", "memories", collected_ids)
    save.set_value("explorer", "last_biome", world.biome)
    save.save("user://aurora_v02.cfg")

func _load_progress() -> void:
    var save := ConfigFile.new()
    if save.load("user://aurora_v02.cfg") == OK:
        var stored = save.get_value("explorer", "memories", {})
        if stored is Dictionary:
            collected_ids = stored

# Keep diagnostic ground only when the procedural scene did not load.
func _set_fallback_for_world() -> void:
    var fallback := get_node_or_null("FallbackEnvironment") as Node3D
    if fallback != null:
        fallback.visible = world.get_child_count() < 10
