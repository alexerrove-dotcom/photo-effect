extends Control

var direction := Vector2.ZERO
var held_id := -1
var knob_offset := Vector2.ZERO
var pad_radius := 73.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_process_input(true)

func _input(event: InputEvent) -> void:
    var size_ := get_viewport_rect().size
    var center := Vector2(104.0, size_.y - 111.0)
    if event is InputEventScreenTouch:
        if event.pressed and held_id == -1 and event.position.x < size_.x * 0.42 and event.position.y > size_.y * 0.44:
            held_id = event.index
            _update_direction(event.position, center)
        elif not event.pressed and event.index == held_id:
            held_id = -1
            direction = Vector2.ZERO
            knob_offset = Vector2.ZERO
            queue_redraw()
    elif event is InputEventScreenDrag and event.index == held_id:
        _update_direction(event.position, center)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and held_id == -1 and event.position.x < size_.x * 0.35 and event.position.y > size_.y * 0.48:
            held_id = 0
            _update_direction(event.position, center)
        elif not event.pressed and held_id == 0:
            held_id = -1
            direction = Vector2.ZERO
            knob_offset = Vector2.ZERO
            queue_redraw()
    elif event is InputEventMouseMotion and held_id == 0 and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        _update_direction(event.position, center)

func _update_direction(point: Vector2, center: Vector2) -> void:
    knob_offset = (point - center).limit_length(pad_radius)
    direction = knob_offset / pad_radius
    queue_redraw()

func _draw() -> void:
    var size_ := get_viewport_rect().size
    var center := Vector2(104.0, size_.y - 111.0)
    draw_circle(center, 85, Color(0.06, 0.13, 0.19, 0.42))
    draw_arc(center, 85, 0, TAU, 72, Color(0.80, 0.89, 0.96, 0.31), 2.5, true)
    draw_circle(center + knob_offset, 35, Color(0.52, 0.75, 0.92, 0.58))
    draw_arc(center + knob_offset, 35, 0, TAU, 40, Color(0.91, 0.95, 1.0, 0.62), 2.0, true)
