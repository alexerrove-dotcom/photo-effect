# Aurora v0.5 — asset provenance and CC0 import

Intended external game-ready assets (downloaded by `python tools/fetch_cc0_assets.py`):

* **Quaternius — Stylized Nature MegaKit, Standard free tier**: https://quaternius.com/packs/stylizednaturemegakit.html . Licensed CC0-1.0, commercial use permitted without required attribution. GitHub mirror: https://github.com/agentkaerf/FreeModels/tree/main/Stylized%20Nature%20MegaKit%5BStandard%5D . Our fetcher downloads individual glTF, PNG, BIN files and recolors only leaf textures, preserving source geometry, UVs and transparency.
* **KayKit — Character Pack: Adventurers, free tier**: https://github.com/KayKit-Game-Assets/KayKit-Character-Pack-Adventures-1.0 . CC0-1.0. `Rogue_Hooded.glb` has a humanoid rig and animation clips. Kept intact; a blue moving cape is created inside Godot.

All other assets in `assets/models/` and `assets/textures/` were generated from the project-owned Python tool scripts; they are original and are fallbacks when CC0 downloads are not installed.

The CC0 assets are not bundled into the offline source ZIP from this chat unless a separate online build has fetched them successfully. **Never claim the source ZIP includes Quaternius/KayKit unless `assets/cc0_nature` and `assets/cc0_hero` are present and populated.**

CC0 isn't the same as 'having no author': the authors remain Quaternius and Kay Lousberg, but credit is not legally required by the CC0 license.
