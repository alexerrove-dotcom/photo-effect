shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never;

uniform vec4 glow_color : source_color = vec4(0.11, 1.0, 0.68, 0.8);
uniform float motion_speed = 0.23;

void vertex() {
    VERTEX.y += sin(VERTEX.x * 0.12 + TIME * 0.50 + VERTEX.z * 0.035) * 1.6;
}

void fragment() {
    float waving = sin(UV.x * 17.0 + TIME * motion_speed * 4.0) * 0.20;
    float columns = 0.50 + 0.50 * sin(UV.x * 87.0 + sin(UV.x * 11.0 + TIME * motion_speed));
    float fade = pow(max(0.0, 1.0 - abs(UV.y * 2.0 - 1.0)), 0.68);
    float pattern = smoothstep(0.22, 0.86, columns + waving) * fade;
    ALBEDO = glow_color.rgb;
    EMISSION = glow_color.rgb * 2.8;
    ALPHA = pattern * glow_color.a * 0.52;
}
