# Model asset provenance — Aurora v0.4

All `assets/models/*_v04.glb` models and `*_v04.png` ground materials in this archive were generated originally with `/tools/build_detail_assets_v04.py` and may be used commercially. They are NOT falsely labeled as Quaternius assets.

The following external packs were verified CC0 and are recommended when replacing procedural geometry with professionally modelled assets:
- Quaternius Stylized Nature MegaKit (116 models): https://quaternius.com/packs/stylizednaturemegakit.html
- KayKit Forest Nature: https://kaylousberg.itch.io/kaykit-forest

No external downloaded models are included in this archive.
