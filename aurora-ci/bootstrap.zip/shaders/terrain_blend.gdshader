shader_type spatial;
render_mode cull_back, diffuse_burley, specular_disabled;
uniform sampler2D ground_tex : source_color, repeat_enable, filter_linear_mipmap;
uniform sampler2D trail_tex : source_color, repeat_enable, filter_linear_mipmap;
uniform bool winter = false;
varying float path_mask;
void vertex() {
    path_mask = COLOR.r;
}
void fragment() {
    vec3 forest = texture(ground_tex, UV).rgb;
    vec3 dirt = texture(trail_tex, UV).rgb;
    float mask = smoothstep(0.01, 0.96, path_mask);
    vec3 color = mix(forest, dirt, mask * (winter ? 0.36 : 0.85));
    ALBEDO = clamp(color * (winter ? vec3(0.96, 1.04, 1.08) : vec3(1.10, 1.03, 0.91)), 0.0, 1.0);
    ROUGHNESS = 1.0;
}
